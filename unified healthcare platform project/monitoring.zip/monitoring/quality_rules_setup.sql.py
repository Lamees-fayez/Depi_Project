# Databricks notebook source
# MAGIC %sql
# MAGIC ALTER DATABASE healthcare_platform 
# MAGIC SET DBPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported');

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 1. احذفي الجدول القديم الذي به مشكلة (تأكدي أنه لا يحتوي على بيانات مهمة!)
# MAGIC DROP TABLE IF EXISTS healthcare_platform.quality_rules;
# MAGIC
# MAGIC -- 2. أنشئيه مع تفعيل الخاصية داخلياً
# MAGIC CREATE TABLE IF NOT EXISTS healthcare_platform.quality_rules (
# MAGIC     rule_id STRING NOT NULL,
# MAGIC     rule_name STRING NOT NULL,
# MAGIC     source_name STRING NOT NULL,
# MAGIC     layer STRING NOT NULL,
# MAGIC     target_table STRING NOT NULL,
# MAGIC     check_type STRING NOT NULL,
# MAGIC     check_column STRING,
# MAGIC     check_sql STRING,
# MAGIC     threshold_warn DOUBLE,
# MAGIC     threshold_fail DOUBLE,
# MAGIC     severity STRING DEFAULT 'WARNING',
# MAGIC     is_active BOOLEAN DEFAULT true,
# MAGIC     created_at TIMESTAMP DEFAULT current_timestamp()
# MAGIC )
# MAGIC USING DELTA
# MAGIC TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported');

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Seed quality_rules with checks for all three layers
# MAGIC TRUNCATE TABLE healthcare_platform.quality_rules;
# MAGIC
# MAGIC INSERT INTO healthcare_platform.quality_rules VALUES
# MAGIC
# MAGIC -- ── Bronze layer checks ────────────────────────────────────────────────────────
# MAGIC
# MAGIC -- 1. No null national IDs in ingestion table
# MAGIC ('QR_001', 'bronze_no_null_national_id',
# MAGIC  'patients_csv', 'bronze',
# MAGIC  'healthcare_platform.bronze_ingestion_patients_csv',
# MAGIC  'null_check', 'national_id', NULL,
# MAGIC  0.0, 0.0, 'CRITICAL', true, current_timestamp()),
# MAGIC
# MAGIC -- 2. No null first names
# MAGIC ('QR_002', 'bronze_no_null_first_name',
# MAGIC  'patients_csv', 'bronze',
# MAGIC  'healthcare_platform.bronze_ingestion_patients_csv',
# MAGIC  'null_check', 'first_name', NULL,
# MAGIC  1.0, 5.0, 'WARNING', true, current_timestamp()),
# MAGIC
# MAGIC -- 3. Rejection rate must stay below threshold
# MAGIC ('QR_003', 'ingestion_rejection_rate',
# MAGIC  'patients_csv', 'bronze',
# MAGIC  'healthcare_platform.metadata_config',
# MAGIC  'custom_sql', NULL,
# MAGIC  'SELECT total_rows_rejected * 100.0 /
# MAGIC   NULLIF(total_rows_loaded + total_rows_rejected, 0)
# MAGIC   AS failure_rate
# MAGIC   FROM healthcare_platform.metadata_config
# MAGIC   WHERE source_name = ''patients_csv''',
# MAGIC  10.0, 30.0, 'WARNING', true, current_timestamp()),
# MAGIC
# MAGIC -- ── Silver layer checks ────────────────────────────────────────────────────────
# MAGIC
# MAGIC -- 4. No duplicate patient IDs in silver
# MAGIC ('QR_004', 'silver_unique_patients',
# MAGIC  'patients', 'silver',
# MAGIC  'hive_metastore.silver.silver_patients',
# MAGIC  'duplicate_check', 'patient_id', NULL,
# MAGIC  0.0, 0.0, 'CRITICAL', true, current_timestamp()),
# MAGIC
# MAGIC -- 5. Age must be between 0 and 130
# MAGIC ('QR_005', 'silver_valid_age',
# MAGIC  'patients', 'silver',
# MAGIC  'hive_metastore.silver.silver_patients',
# MAGIC  'range_check', 'age_years',
# MAGIC  'age_years < 0 OR age_years > 130',
# MAGIC  0.0, 1.0, 'WARNING', true, current_timestamp()),
# MAGIC
# MAGIC -- 6. Systolic BP must be > diastolic BP
# MAGIC ('QR_006', 'silver_bp_systolic_gt_diastolic',
# MAGIC  'vitals', 'silver',
# MAGIC  'hive_metastore.silver.silver_vitals',
# MAGIC  'custom_sql', NULL,
# MAGIC  'SELECT COUNT(*) * 100.0 / NULLIF(COUNT(*), 0) AS failure_rate
# MAGIC   FROM hive_metastore.silver.silver_vitals
# MAGIC   WHERE systolic_bp IS NOT NULL
# MAGIC     AND diastolic_bp IS NOT NULL
# MAGIC     AND systolic_bp <= diastolic_bp',
# MAGIC  0.0, 0.5, 'CRITICAL', true, current_timestamp()),
# MAGIC
# MAGIC -- 7. SpO2 must be between 70 and 100
# MAGIC ('QR_007', 'silver_spo2_range',
# MAGIC  'vitals', 'silver',
# MAGIC  'hive_metastore.silver.silver_vitals',
# MAGIC  'range_check', 'spo2_pct',
# MAGIC  'spo2_pct < 70 OR spo2_pct > 100',
# MAGIC  0.5, 2.0, 'WARNING', true, current_timestamp()),
# MAGIC
# MAGIC -- 8. No null drug names in medications
# MAGIC ('QR_008', 'silver_no_null_drug_name',
# MAGIC  'medications', 'silver',
# MAGIC  'hive_metastore.silver.silver_medications',
# MAGIC  'null_check', 'drug_name', NULL,
# MAGIC  0.0, 1.0, 'WARNING', true, current_timestamp()),
# MAGIC
# MAGIC -- ── Gold layer checks ──────────────────────────────────────────────────────────
# MAGIC
# MAGIC -- 9. Every patient in gold must have a risk level
# MAGIC ('QR_009', 'gold_no_null_risk_level',
# MAGIC  'patients', 'gold',
# MAGIC  'hive_metastore.gold.gold_risk_scores',
# MAGIC  'null_check', 'risk_level', NULL,
# MAGIC  0.0, 0.0, 'CRITICAL', true, current_timestamp()),
# MAGIC
# MAGIC -- 10. Composite risk score must be non-negative
# MAGIC ('QR_010', 'gold_risk_score_non_negative',
# MAGIC  'patients', 'gold',
# MAGIC  'hive_metastore.gold.gold_risk_scores',
# MAGIC  'range_check', 'composite_risk_score',
# MAGIC  'composite_risk_score < 0',
# MAGIC  0.0, 0.0, 'CRITICAL', true, current_timestamp()),
# MAGIC
# MAGIC -- 11. High risk patients must have at least one vital reading
# MAGIC ('QR_011', 'gold_high_risk_has_readings',
# MAGIC  'patients', 'gold',
# MAGIC  'hive_metastore.gold.gold_patient_summary',
# MAGIC  'custom_sql', NULL,
# MAGIC  'SELECT COUNT(*) * 100.0 /
# MAGIC   NULLIF(SUM(CASE WHEN risk_level = ''HIGH'' THEN 1 ELSE 0 END), 0)
# MAGIC   AS failure_rate
# MAGIC   FROM hive_metastore.gold.gold_doctor_dashboard
# MAGIC   WHERE risk_level = ''HIGH''
# MAGIC     AND (total_readings IS NULL OR total_readings = 0)',
# MAGIC  0.0, 5.0, 'WARNING', true, current_timestamp());