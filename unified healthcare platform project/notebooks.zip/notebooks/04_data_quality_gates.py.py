# Databricks notebook source
# notebooks/04_data_quality_gates.py
# Data Quality Gates — runs checks across bronze/silver/gold
# and alerts on failures

import uuid
import json
import urllib.request
from datetime import datetime, timezone
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

RULES_TABLE   = "healthcare_platform.quality_rules"
RESULTS_TABLE = "healthcare_platform.quality_results"
ALERTS_TABLE  = "healthcare_platform.quality_alerts"

# ── Run ID for this quality check session ──────────────────────────────────────
RUN_ID = datetime.now(timezone.utc).strftime("QC_%Y%m%d_%H%M%S")
print(f"Quality Gate Run ID: {RUN_ID}")
print("=" * 60)

# COMMAND ----------

# Cell 2: Load active quality rules
def load_active_rules() -> list[dict]:
    rows = spark.sql(f"""
        SELECT * FROM {RULES_TABLE}
        WHERE is_active = true
        ORDER BY layer, rule_id
    """).collect()

    rules = [row.asDict() for row in rows]
    print(f"Loaded {len(rules)} active quality rules\n")
    return rules

# COMMAND ----------

# Cell 3: Check executors — one per check_type

def run_null_check(rule: dict) -> dict:
    """
    Checks what percentage of rows have NULL in check_column.
    """
    table  = rule["target_table"]
    column = rule["check_column"]

    try:
        result = spark.sql(f"""
            SELECT
                COUNT(*)                                AS total,
                COUNT_IF(`{column}` IS NULL
                      OR TRIM(CAST(`{column}` AS STRING)) = '')
                                                        AS failed,
                COUNT_IF(`{column}` IS NULL
                      OR TRIM(CAST(`{column}` AS STRING)) = '')
                * 100.0 / NULLIF(COUNT(*), 0)           AS failure_rate
            FROM {table}
        """).first()

        return {
            "records_checked": result["total"],
            "records_failed":  result["failed"],
            "failure_rate":    round(result["failure_rate"] or 0, 4)
        }
    except Exception as e:
        return {"error": str(e)}


def run_duplicate_check(rule: dict) -> dict:
    """
    Checks for duplicate values in check_column.
    """
    table  = rule["target_table"]
    column = rule["check_column"]

    try:
        result = spark.sql(f"""
            SELECT
                COUNT(*) AS total,
                SUM(dup_count - 1) AS failed,
                SUM(dup_count - 1) * 100.0
                    / NULLIF(COUNT(*), 0) AS failure_rate
            FROM (
                SELECT `{column}`, COUNT(*) AS dup_count
                FROM {table}
                GROUP BY `{column}`
                HAVING COUNT(*) > 1
            ) dups
            CROSS JOIN (SELECT COUNT(*) AS total FROM {table}) t
        """).first()

        failed = result["failed"] or 0
        total  = spark.sql(
            f"SELECT COUNT(*) AS n FROM {table}"
        ).first()["n"]

        return {
            "records_checked": total,
            "records_failed":  int(failed),
            "failure_rate":    round(
                float(failed) / max(total, 1) * 100, 4
            )
        }
    except Exception as e:
        return {"error": str(e)}


def run_range_check(rule: dict) -> dict:
    """
    Counts rows matching a WHERE condition (the invalid condition).
    check_sql holds the WHERE clause for bad rows.
    """
    table     = rule["target_table"]
    condition = rule["check_sql"]

    try:
        result = spark.sql(f"""
            SELECT
                COUNT(*)                            AS total,
                COUNT_IF({condition})               AS failed,
                COUNT_IF({condition}) * 100.0
                    / NULLIF(COUNT(*), 0)           AS failure_rate
            FROM {table}
        """).first()

        return {
            "records_checked": result["total"],
            "records_failed":  result["failed"],
            "failure_rate":    round(result["failure_rate"] or 0, 4)
        }
    except Exception as e:
        return {"error": str(e)}


def run_custom_sql_check(rule: dict) -> dict:
    """
    Executes a custom SQL that returns a single failure_rate value.
    """
    sql_query = rule["check_sql"]

    try:
        result = spark.sql(sql_query).first()
        rate   = float(result["failure_rate"] or 0)

        return {
            "records_checked": -1,   # unknown for custom checks
            "records_failed":  -1,
            "failure_rate":    round(rate, 4)
        }
    except Exception as e:
        return {"error": str(e)}

# COMMAND ----------

# Cell 4: Evaluate result against thresholds

def evaluate_status(
    failure_rate: float,
    threshold_warn: float,
    threshold_fail: float,
    severity: str
) -> tuple[str, str]:
    """
    Returns (status, message) based on thresholds.
    PASS → WARN → FAIL
    """
    if failure_rate <= threshold_warn:
        return "PASS", f"Failure rate {failure_rate:.2f}% is within limits."

    elif failure_rate <= threshold_fail:
        return "WARN", (
            f"Failure rate {failure_rate:.2f}% exceeds warn threshold "
            f"({threshold_warn}%)."
        )
    else:
        return "FAIL", (
            f"Failure rate {failure_rate:.2f}% exceeds fail threshold "
            f"({threshold_fail}%). Severity: {severity}."
        )

# COMMAND ----------

# Cell 5: Master quality gate runner

def run_all_quality_gates(rules: list[dict]) -> list[dict]:
    """
    Runs every active rule and collects results.
    """
    results   = []
    executor_map = {
        "null_check":      run_null_check,
        "duplicate_check": run_duplicate_check,
        "range_check":     run_range_check,
        "custom_sql":      run_custom_sql_check,
    }

    for rule in rules:
        rule_id    = rule["rule_id"]
        rule_name  = rule["rule_name"]
        check_type = rule["check_type"]
        layer      = rule["layer"]

        print(f"  Running [{layer.upper()}] {rule_name}...", end=" ")

        executor = executor_map.get(check_type)
        if not executor:
            print(f"❓ Unknown check_type: {check_type}")
            continue

        check_result = executor(rule)

        if "error" in check_result:
            status  = "ERROR"
            message = check_result["error"]
            print(f"❌ ERROR: {message}")
            # Inside run_all_quality_gates() replace the results.append() block
            # Success case
            results.append({
                "result_id":        str(uuid.uuid4()),
                "run_id":           RUN_ID,
                "rule_id":          str(rule_id),
                "rule_name":        str(rule_name),
                "source_name":      str(rule["source_name"]),
                "layer":            str(layer),
                "check_type":       str(check_type),
                "records_checked":  float(check_result.get("records_checked") or 0),
                "records_failed":   float(check_result.get("records_failed")  or 0),
                "failure_rate_pct": float(check_result.get("failure_rate")    or 0),
                "status":           status,
                "message":          message,
            })
            continue

        status, message = evaluate_status(
            check_result["failure_rate"],
            rule["threshold_warn"],
            rule["threshold_fail"],
            rule["severity"]
        )

        icon = {"PASS": "✅", "WARN": "⚠️ ", "FAIL": "❌"}.get(
            status, "❓"
        )
        print(f"{icon} {status} — {message}")

      # Error case
        results.append({
            "result_id":        str(uuid.uuid4()),
            "run_id":           RUN_ID,
            "rule_id":          str(rule_id),
            "rule_name":        str(rule_name),
            "source_name":      str(rule["source_name"]),
            "layer":            str(layer),
            "check_type":       str(check_type),
            "records_checked":  float(0),
            "records_failed":   float(0),
            "failure_rate_pct": float(0),
            "status":           "ERROR",
            "message":          str(message)[:500],
        })

    return results

# COMMAND ----------

# Cell 6: Write using SQL INSERT — bypasses all type merge issues
def write_quality_results(results: list[dict]) -> None:
    if not results:
        print("No results to write.")
        return

    from datetime import timezone

    for r in results:
        result_id        = str(r["result_id"]).replace("'", "''")
        run_id           = str(r["run_id"]).replace("'", "''")
        rule_id          = str(r["rule_id"]).replace("'", "''")
        rule_name        = str(r["rule_name"]).replace("'", "''")
        source_name      = str(r["source_name"]).replace("'", "''")
        layer            = str(r["layer"]).replace("'", "''")
        check_type       = str(r["check_type"]).replace("'", "''")
        records_checked  = float(r.get("records_checked")  or 0)
        records_failed   = float(r.get("records_failed")   or 0)
        failure_rate_pct = float(r.get("failure_rate_pct") or 0)
        status           = str(r["status"]).replace("'", "''")
        message          = str(r["message"])[:500].replace("'", "''")

        spark.sql(f"""
            INSERT INTO healthcare_platform.quality_results
                (result_id, run_id, rule_id, rule_name,
                 source_name, layer, check_type,
                 records_checked, records_failed, failure_rate_pct,
                 status, message, checked_at)
            VALUES (
                '{result_id}',
                '{run_id}',
                '{rule_id}',
                '{rule_name}',
                '{source_name}',
                '{layer}',
                '{check_type}',
                CAST({records_checked}  AS DOUBLE),
                CAST({records_failed}   AS DOUBLE),
                CAST({failure_rate_pct} AS DOUBLE),
                '{status}',
                '{message}',
                current_timestamp()
            )
        """)

    print(f"\n📋 Written {len(results)} quality results")

# COMMAND ----------

# Cell 7: Alert builder and sender

def build_alert_summary(results: list[dict]) -> list[dict]:
    """
    Filters results to FAIL and WARN statuses for alerting.
    """
    return [
        r for r in results
        if r["status"] in ("FAIL", "WARN", "ERROR")
    ]


def send_slack_alert(
    alerts: list[dict],
    run_id: str,
    webhook_url: str
) -> None:
    """
    Sends a formatted Slack message for all failed checks.
    """
    if not alerts:
        return

    fail_count = len([a for a in alerts if a["status"] == "FAIL"])
    warn_count = len([a for a in alerts if a["status"] == "WARN"])
    err_count  = len([a for a in alerts if a["status"] == "ERROR"])

    icon = ":red_circle:" if fail_count > 0 else ":warning:"

    rows = "\n".join([
        f"  • `{a['layer'].upper()}` *{a['rule_name']}*: "
        f"{a['status']} — {a['message'][:80]}"
        for a in alerts
    ])

    payload = {
        "attachments": [{
            "color": "#E24B4A" if fail_count > 0 else "#EF9F27",
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": (
                            f"{icon}  Data Quality Alert — "
                            f"Run {run_id}"
                        )
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {"type": "mrkdwn",
                         "text": f"*FAIL:* {fail_count}"},
                        {"type": "mrkdwn",
                         "text": f"*WARN:* {warn_count}"},
                        {"type": "mrkdwn",
                         "text": f"*ERROR:* {err_count}"},
                    ]
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Failed checks:*\n{rows}"
                    }
                }
            ]
        }]
    }

    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        webhook_url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        print(f"Slack alert sent — HTTP {resp.status}")


def write_alert_log(
    alerts: list[dict],
    run_id: str,
    channel: str
) -> None:
    if not alerts:
        return

    alert_rows = [{
        "alert_id":     str(uuid.uuid4()),
        "run_id":       run_id,
        "severity":     a["status"],
        "rule_name":    a["rule_name"],
        "message":      a["message"],
        "alert_channel": channel,
    } for a in alerts]

    alert_df = spark.createDataFrame(alert_rows)
    (
        alert_df.write
        .format("delta")
        .mode("append")
        .saveAsTable(ALERTS_TABLE)
    )
    print(f"📣 {len(alert_rows)} alert(s) logged to {ALERTS_TABLE}")

# COMMAND ----------

# Cell 8: Run summary printer

def print_run_summary(results: list[dict]) -> None:
    total  = len(results)
    passed = len([r for r in results if r["status"] == "PASS"])
    warned = len([r for r in results if r["status"] == "WARN"])
    failed = len([r for r in results if r["status"] == "FAIL"])
    errors = len([r for r in results if r["status"] == "ERROR"])

    print("\n" + "=" * 60)
    print(f"  QUALITY GATE SUMMARY — {RUN_ID}")
    print("=" * 60)
    print(f"  Total checks : {total}")
    print(f"  ✅ PASS      : {passed}")
    print(f"  ⚠️  WARN      : {warned}")
    print(f"  ❌ FAIL      : {failed}")
    print(f"  ❓ ERROR     : {errors}")
    print("=" * 60)

    if failed > 0:
        print("\n  FAILED CHECKS:")
        for r in results:
            if r["status"] == "FAIL":
                print(
                    f"  ✗ [{r['layer'].upper()}] "
                    f"{r['rule_name']}: {r['message']}"
                )

    overall = (
        "PASSED" if failed == 0 and errors == 0
        else "FAILED"
    )
    print(f"\n  Overall status: {overall}")
    print("=" * 60)

# COMMAND ----------

# Cell 9: Safety check then orchestrate
from datetime import datetime, timezone

# Redefine RUN_ID if kernel was restarted
if 'RUN_ID' not in dir():
    RUN_ID = datetime.now(timezone.utc).strftime("QC_%Y%m%d_%H%M%S")
    print(f"RUN_ID redefined: {RUN_ID}")

print(f"\n{'='*60}")
print(f"  DATA QUALITY GATES STARTING")
print(f"  Run ID : {RUN_ID}")
print(f"{'='*60}\n")

# Step 1: Load rules
rules = load_active_rules()

# Step 2: Run all checks
print("Running quality checks:\n")
results = run_all_quality_gates(rules)

# Step 3: Write results
write_quality_results(results)

# Step 4: Build alerts
alerts = build_alert_summary(results)

# Step 5: Send Slack alert if configured
try:
    slack_url = dbutils.secrets.get(
        "healthcare-scope", "slack-webhook-url"
    )
    if alerts:
        send_slack_alert(alerts, RUN_ID, slack_url)
        write_alert_log(alerts, RUN_ID, "slack")
    else:
        print("✅ No alerts to send — all checks passed.")
except Exception as e:
    print(f"Slack alert skipped (secret not set or error): {e}")

# Step 6: Print summary
print_run_summary(results)

# COMMAND ----------

# Cell 10: Verify — query the results table
display(spark.sql(f"""
    SELECT
        layer,
        rule_name,
        check_type,
        records_checked,
        records_failed,
        failure_rate_pct,
        status,
        message
    FROM {RESULTS_TABLE}
    WHERE run_id = '{RUN_ID}'
    ORDER BY
        CASE status
            WHEN 'FAIL'  THEN 1
            WHEN 'ERROR' THEN 2
            WHEN 'WARN'  THEN 3
            ELSE 4
        END,
        layer
"""))