# Databricks notebook source
# MAGIC %sql
# MAGIC USE healthcare_platform;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE healthcare_platform.metadata_config;

# COMMAND ----------

# MAGIC %sql
# MAGIC USE healthcare_platform;
# MAGIC
# MAGIC -- CSV ingestion (file_source_path already exists, skip it)
# MAGIC ALTER TABLE metadata_config ADD COLUMN file_format         STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN csv_delimiter       STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN csv_header          BOOLEAN;
# MAGIC ALTER TABLE metadata_config ADD COLUMN csv_encoding        STRING;
# MAGIC
# MAGIC -- Schema variation handling
# MAGIC ALTER TABLE metadata_config ADD COLUMN expected_columns    STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN optional_columns    STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN column_mapping      STRING;
# MAGIC
# MAGIC -- National ID filter
# MAGIC ALTER TABLE metadata_config ADD COLUMN national_id_col     STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN national_id_filter  BOOLEAN;
# MAGIC ALTER TABLE metadata_config ADD COLUMN national_id_length  INT;
# MAGIC
# MAGIC -- Ingestion tracking
# MAGIC ALTER TABLE metadata_config ADD COLUMN last_ingested_at    TIMESTAMP;
# MAGIC ALTER TABLE metadata_config ADD COLUMN last_file_loaded    STRING;
# MAGIC ALTER TABLE metadata_config ADD COLUMN total_rows_loaded   LONG;
# MAGIC ALTER TABLE metadata_config ADD COLUMN total_rows_rejected LONG;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE metadata_config ALTER COLUMN file_format         SET DEFAULT 'delta';
# MAGIC ALTER TABLE metadata_config ALTER COLUMN csv_delimiter       SET DEFAULT ',';
# MAGIC ALTER TABLE metadata_config ALTER COLUMN csv_header          SET DEFAULT true;
# MAGIC ALTER TABLE metadata_config ALTER COLUMN csv_encoding        SET DEFAULT 'UTF-8';
# MAGIC ALTER TABLE metadata_config ALTER COLUMN national_id_filter  SET DEFAULT false;
# MAGIC ALTER TABLE metadata_config ALTER COLUMN national_id_length  SET DEFAULT 14;
# MAGIC ALTER TABLE metadata_config ALTER COLUMN total_rows_loaded   SET DEFAULT 0;
# MAGIC ALTER TABLE metadata_config ALTER COLUMN total_rows_rejected SET DEFAULT 0;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Backfill patients
# MAGIC UPDATE healthcare_platform.metadata_config
# MAGIC SET
# MAGIC     file_format         = 'delta',
# MAGIC     csv_delimiter       = ',',
# MAGIC     csv_header          = true,
# MAGIC     csv_encoding        = 'UTF-8',
# MAGIC     expected_columns    = '["patient_id","first_name","last_name","date_of_birth","gender","blood_type","contact_email"]',
# MAGIC     optional_columns    = '["contact_email","blood_type"]',
# MAGIC     column_mapping      = '{}',
# MAGIC     national_id_col     = 'patient_id',
# MAGIC     national_id_filter  = false,
# MAGIC     national_id_length  = 14,
# MAGIC     total_rows_loaded   = 0,
# MAGIC     total_rows_rejected = 0
# MAGIC WHERE source_name = 'patients';
# MAGIC
# MAGIC -- Backfill vitals
# MAGIC UPDATE healthcare_platform.metadata_config
# MAGIC SET
# MAGIC     file_format         = 'delta',
# MAGIC     csv_delimiter       = ',',
# MAGIC     csv_header          = true,
# MAGIC     csv_encoding        = 'UTF-8',
# MAGIC     expected_columns    = '["vital_id","patient_id","recorded_at","systolic_bp","diastolic_bp","heart_rate","temperature_c","spo2_pct","weight_kg"]',
# MAGIC     optional_columns    = '["weight_kg","temperature_c"]',
# MAGIC     column_mapping      = '{}',
# MAGIC     national_id_col     = NULL,
# MAGIC     national_id_filter  = false,
# MAGIC     national_id_length  = 14,
# MAGIC     total_rows_loaded   = 0,
# MAGIC     total_rows_rejected = 0
# MAGIC WHERE source_name = 'vitals';
# MAGIC
# MAGIC -- Backfill medications
# MAGIC UPDATE healthcare_platform.metadata_config
# MAGIC SET
# MAGIC     file_format         = 'delta',
# MAGIC     csv_delimiter       = ',',
# MAGIC     csv_header          = true,
# MAGIC     csv_encoding        = 'UTF-8',
# MAGIC     expected_columns    = '["med_id","patient_id","drug_name","dosage_mg","frequency","prescribed_at","prescribing_doc"]',
# MAGIC     optional_columns    = '["prescribing_doc"]',
# MAGIC     column_mapping      = '{}',
# MAGIC     national_id_col     = NULL,
# MAGIC     national_id_filter  = false,
# MAGIC     national_id_length  = 14,
# MAGIC     total_rows_loaded   = 0,
# MAGIC     total_rows_rejected = 0
# MAGIC WHERE source_name = 'medications';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- See exactly what source_name values exist and their character length
# MAGIC SELECT 
# MAGIC     source_name,
# MAGIC     LENGTH(source_name)  AS name_length,
# MAGIC     file_format,
# MAGIC     national_id_filter,
# MAGIC     total_rows_loaded
# MAGIC FROM healthcare_platform.metadata_config
# MAGIC ORDER BY source_name;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     source_name,
# MAGIC     file_format,
# MAGIC     csv_delimiter,
# MAGIC     csv_header,
# MAGIC     csv_encoding,
# MAGIC     national_id_col,
# MAGIC     national_id_filter,
# MAGIC     national_id_length,
# MAGIC     total_rows_loaded,
# MAGIC     total_rows_rejected,
# MAGIC     expected_columns,
# MAGIC     optional_columns
# MAGIC FROM healthcare_platform.metadata_config
# MAGIC WHERE source_name IN ('patients', 'vitals', 'medications')
# MAGIC ORDER BY source_name;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO healthcare_platform.metadata_config (
# MAGIC     source_name, source_table, target_layer, primary_key,
# MAGIC     timestamp_col, is_active, coalesce_fields, load_strategy,
# MAGIC     last_updated, file_source_path, file_format, csv_delimiter,
# MAGIC     csv_header, csv_encoding, expected_columns, optional_columns,
# MAGIC     column_mapping, national_id_col, national_id_filter,
# MAGIC     national_id_length, last_ingested_at, last_file_loaded,
# MAGIC     total_rows_loaded, total_rows_rejected
# MAGIC )
# MAGIC VALUES (
# MAGIC     'patients_csv',
# MAGIC     'healthcare_platform.patients',
# MAGIC     'bronze',
# MAGIC     'national_id',
# MAGIC     'upload_timestamp',
# MAGIC     true,
# MAGIC     '["first_name","last_name","national_id"]',
# MAGIC     'incremental',
# MAGIC     current_timestamp(),
# MAGIC     '/FileStore/healthcare/uploads/',
# MAGIC     'csv',
# MAGIC     ',',
# MAGIC     true,
# MAGIC     'UTF-8',
# MAGIC     '["national_id","first_name","last_name","date_of_birth","gender","blood_type","contact_email"]',
# MAGIC     '["blood_type","contact_email","gender"]',
# MAGIC     '{"nat_id":"national_id","name":"first_name","surname":"last_name"}',
# MAGIC     'national_id',
# MAGIC     true,
# MAGIC     14,
# MAGIC     NULL,
# MAGIC     NULL,
# MAGIC     0,
# MAGIC     0
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the full updated structure
# MAGIC SELECT
# MAGIC     source_name,
# MAGIC     file_format,
# MAGIC     national_id_filter,
# MAGIC     national_id_col,
# MAGIC     national_id_length,
# MAGIC     file_source_path,
# MAGIC     is_active,
# MAGIC     load_strategy
# MAGIC FROM healthcare_platform.metadata_config
# MAGIC ORDER BY source_name;