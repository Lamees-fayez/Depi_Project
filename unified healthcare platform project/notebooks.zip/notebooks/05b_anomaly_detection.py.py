# Databricks notebook source
# Cell 1: Anomaly detection setup
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from datetime import datetime, timezone

spark = SparkSession.builder.getOrCreate()

ANOMALY_TABLE = "healthcare_platform.anomaly_flags"
RUN_ID = datetime.now(timezone.utc).strftime("ANO_%Y%m%d_%H%M%S")

# Create anomaly table if not exists
spark.sql("""
    CREATE TABLE IF NOT EXISTS healthcare_platform.anomaly_flags (
        anomaly_id      STRING,
        patient_id      STRING,
        vital_id        STRING,
        recorded_at     TIMESTAMP,
        anomaly_type    STRING,
        metric_name     STRING,
        metric_value    DOUBLE,
        expected_range  STRING,
        severity        STRING,
        detected_at     TIMESTAMP
    )
    USING DELTA
""")

spark.sql("""
    ALTER TABLE healthcare_platform.anomaly_flags
    SET TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported')
""")

spark.sql("""
    ALTER TABLE healthcare_platform.anomaly_flags
    ALTER COLUMN detected_at SET DEFAULT current_timestamp()
""")

print(f"✅ Anomaly detection starting — Run: {RUN_ID}")

# COMMAND ----------

# Cell 2: Statistical anomaly detection using Z-score
def detect_statistical_anomalies() -> int:
    """
    Flags vitals that are more than 3 standard deviations
    from the patient's own historical mean.
    Per-patient Z-score anomaly detection.
    """
    vitals_df = spark.sql("""
        SELECT
            vital_id,
            patient_id,
            recorded_at,
            systolic_bp,
            diastolic_bp,
            heart_rate,
            spo2_pct,
            temperature_c
        FROM silver.silver_vitals
        WHERE recorded_at >= DATE_SUB(current_date(), 90)
    """)

    # Compute per-patient statistics for each metric
    metrics = [
        "systolic_bp", "diastolic_bp",
        "heart_rate", "spo2_pct", "temperature_c"
    ]

    patient_window = Window.partitionBy("patient_id")
    anomaly_rows   = []

    for metric in metrics:
        # Add mean and stddev per patient
        stats_df = vitals_df.withColumn(
            f"{metric}_mean",
            F.avg(F.col(metric)).over(patient_window)
        ).withColumn(
            f"{metric}_std",
            F.stddev(F.col(metric)).over(patient_window)
        ).withColumn(
            f"{metric}_zscore",
            F.abs(
                (F.col(metric) - F.col(f"{metric}_mean"))
                / F.when(
                    F.col(f"{metric}_std") == 0, 1
                ).otherwise(F.col(f"{metric}_std"))
            )
        )

        # Flag rows with Z-score > 3
        flagged = stats_df.filter(
            (F.col(f"{metric}_zscore") > 3) &
            F.col(metric).isNotNull()
        ).select(
            F.expr("uuid()")              .alias("anomaly_id"),
            F.col("patient_id"),
            F.col("vital_id"),
            F.col("recorded_at"),
            F.lit("STATISTICAL_OUTLIER") .alias("anomaly_type"),
            F.lit(metric)                .alias("metric_name"),
            F.col(metric).cast("double") .alias("metric_value"),
            F.concat(
                F.lit("mean±3σ: "),
                F.round(F.col(f"{metric}_mean"), 1).cast("string"),
                F.lit("±"),
                F.round(F.col(f"{metric}_std") * 3, 1).cast("string")
            )                            .alias("expected_range"),
            F.when(
                F.col(f"{metric}_zscore") > 5, "CRITICAL"
            ).otherwise("WARNING")       .alias("severity"),
            F.current_timestamp()        .alias("detected_at")
        )

        anomaly_rows.append(flagged)
        count = flagged.count()
        if count > 0:
            print(f"   ⚠️  {metric}: {count} statistical outliers")

    return anomaly_rows


anomaly_dfs = detect_statistical_anomalies()

# COMMAND ----------

# Cell 3: Clinical threshold-based anomaly detection
def detect_clinical_anomalies():
    """
    Flags vitals that breach hard clinical thresholds.
    These are absolute rules regardless of patient history.
    """
    clinical_df = spark.sql("""
        SELECT
            vital_id,
            patient_id,
            recorded_at,
            systolic_bp,
            diastolic_bp,
            heart_rate,
            spo2_pct,
            temperature_c
        FROM silver.silver_vitals
        WHERE recorded_at >= DATE_SUB(current_date(), 30)
    """)

    # Define clinical thresholds
    thresholds = [
        ("systolic_bp",   "systolic_bp > 180",
         "Hypertensive Crisis",    "CRITICAL", ">180 mmHg"),
        ("systolic_bp",   "systolic_bp < 90",
         "Hypotension",            "CRITICAL", "<90 mmHg"),
        ("spo2_pct",      "spo2_pct < 90",
         "Critical Hypoxemia",     "CRITICAL", "<90%"),
        ("spo2_pct",      "spo2_pct < 94",
         "Hypoxemia",              "WARNING",  "<94%"),
        ("heart_rate",    "heart_rate > 150",
         "Tachycardia",            "CRITICAL", ">150 bpm"),
        ("heart_rate",    "heart_rate < 40",
         "Bradycardia",            "CRITICAL", "<40 bpm"),
        ("temperature_c", "temperature_c > 39.5",
         "High Fever",             "WARNING",  ">39.5°C"),
        ("temperature_c", "temperature_c > 41.0",
         "Hyperpyrexia",           "CRITICAL", ">41.0°C"),
        ("diastolic_bp",  "diastolic_bp > 120",
         "Severe Hypertension",    "CRITICAL", ">120 mmHg"),
    ]

    clinical_rows = []

    for metric, condition, anomaly_type, severity, expected in thresholds:
        flagged = clinical_df.filter(condition).select(
            F.expr("uuid()")            .alias("anomaly_id"),
            F.col("patient_id"),
            F.col("vital_id"),
            F.col("recorded_at"),
            F.lit(anomaly_type)         .alias("anomaly_type"),
            F.lit(metric)               .alias("metric_name"),
            F.col(metric).cast("double").alias("metric_value"),
            F.lit(f"Normal: {expected}").alias("expected_range"),
            F.lit(severity)             .alias("severity"),
            F.current_timestamp()       .alias("detected_at")
        )

        count = flagged.count()
        if count > 0:
            icon = "🚨" if severity == "CRITICAL" else "⚠️ "
            print(f"   {icon} {anomaly_type}: {count} patient(s)")
            clinical_rows.append(flagged)

    return clinical_rows

clinical_dfs = detect_clinical_anomalies()

# COMMAND ----------

# Cell 4: Combine and write all anomalies
from functools import reduce
from pyspark.sql import DataFrame

all_anomaly_dfs = anomaly_dfs + clinical_dfs

if all_anomaly_dfs:
    combined = reduce(DataFrame.unionByName, all_anomaly_dfs)
    total    = combined.count()

    if total > 0:
        combined.write \
            .format("delta") \
            .mode("append") \
            .saveAsTable(ANOMALY_TABLE)

        print(f"\n✅ {total:,} anomalies written to {ANOMALY_TABLE}")

        print("\nAnomaly breakdown:")
        combined.groupBy("anomaly_type", "severity") \
                .count() \
                .orderBy("severity", "anomaly_type") \
                .show(truncate=False)
    else:
        print("✅ No anomalies detected in current data")
else:
    print("✅ No anomalies detected in current data")