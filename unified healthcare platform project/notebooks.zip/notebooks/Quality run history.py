# Databricks notebook source
# MAGIC %sql
# MAGIC ALTER TABLE healthcare_platform.quality_results
# MAGIC ADD COLUMN checked_at TIMESTAMP;
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.quality_results
# MAGIC SET TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported');
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.quality_results
# MAGIC ALTER COLUMN checked_at SET DEFAULT current_timestamp();
# MAGIC
# MAGIC -- Backfill existing rows
# MAGIC UPDATE healthcare_platform.quality_results
# MAGIC SET checked_at = current_timestamp()
# MAGIC WHERE checked_at IS NULL;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE healthcare_platform.quality_results;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW healthcare_platform.vw_quality_health AS
# MAGIC SELECT
# MAGIC     run_id,
# MAGIC     MIN(checked_at)                             AS run_started_at,
# MAGIC     COUNT(*)                                    AS total_checks,
# MAGIC     COUNT_IF(status = 'PASS')                   AS passed,
# MAGIC     COUNT_IF(status = 'WARN')                   AS warned,
# MAGIC     COUNT_IF(status = 'FAIL')                   AS failed,
# MAGIC     COUNT_IF(status = 'ERROR')                  AS errors,
# MAGIC     CASE
# MAGIC         WHEN COUNT_IF(status = 'FAIL')  > 0 THEN 'FAILED'
# MAGIC         WHEN COUNT_IF(status = 'ERROR') > 0 THEN 'ERROR'
# MAGIC         WHEN COUNT_IF(status = 'WARN')  > 0 THEN 'WARNING'
# MAGIC         ELSE 'PASSED'
# MAGIC     END                                         AS overall_status
# MAGIC FROM healthcare_platform.quality_results
# MAGIC GROUP BY run_id
# MAGIC ORDER BY run_started_at DESC;
# MAGIC
# MAGIC CREATE OR REPLACE VIEW healthcare_platform.vw_latest_quality AS
# MAGIC SELECT *
# MAGIC FROM (
# MAGIC     SELECT *,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY rule_id
# MAGIC             ORDER BY checked_at DESC
# MAGIC         ) AS rn
# MAGIC     FROM healthcare_platform.quality_results
# MAGIC )
# MAGIC WHERE rn = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM healthcare_platform.vw_quality_health LIMIT 5;
# MAGIC SELECT * FROM healthcare_platform.vw_latest_quality LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW healthcare_platform.vw_quality_health AS
# MAGIC SELECT
# MAGIC     run_id,
# MAGIC     MIN(checked_at)                             AS run_started_at,
# MAGIC     COUNT(*)                                    AS total_checks,
# MAGIC     COUNT_IF(status = 'PASS')                   AS passed,
# MAGIC     COUNT_IF(status = 'WARN')                   AS warned,
# MAGIC     COUNT_IF(status = 'FAIL')                   AS failed,
# MAGIC     COUNT_IF(status = 'ERROR')                  AS errors,
# MAGIC     CASE
# MAGIC         WHEN COUNT_IF(status = 'FAIL')  > 0 THEN 'FAILED'
# MAGIC         WHEN COUNT_IF(status = 'ERROR') > 0 THEN 'ERROR'
# MAGIC         WHEN COUNT_IF(status = 'WARN')  > 0 THEN 'WARNING'
# MAGIC         ELSE 'PASSED'
# MAGIC     END                                         AS overall_status
# MAGIC FROM healthcare_platform.quality_results
# MAGIC GROUP BY run_id
# MAGIC ORDER BY run_started_at DESC;
# MAGIC
# MAGIC CREATE OR REPLACE VIEW healthcare_platform.vw_latest_quality AS
# MAGIC SELECT *
# MAGIC FROM (
# MAGIC     SELECT *,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY rule_id
# MAGIC             ORDER BY checked_at DESC
# MAGIC         ) AS rn
# MAGIC     FROM healthcare_platform.quality_results
# MAGIC )
# MAGIC WHERE rn = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM healthcare_platform.vw_quality_health LIMIT 5;
# MAGIC SELECT * FROM healthcare_platform.vw_latest_quality LIMIT 5;