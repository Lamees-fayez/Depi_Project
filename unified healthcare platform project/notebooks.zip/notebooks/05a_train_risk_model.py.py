# Databricks notebook source
# Cell 1: Imports
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.ml import Pipeline
from pyspark.ml.feature import (
    VectorAssembler, StringIndexer,
    StandardScaler, IndexToString
)
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from datetime import datetime, timezone
import json

spark = SparkSession.builder.getOrCreate()

# هذا سيحفظ النموذج في نظام ملفات Spark الموزع
# مثال: استبدلي الأسماء بما يناسب مشروعك
# المسار المحدث الآن
MODEL_PATH = "/Volumes/workspace/healthcare_platform/my_model_storage/risk_model"
METRICS_TABLE = "workspace.healthcare_platform.model_metrics"
RUN_ID = datetime.now(timezone.utc).strftime("ML_%Y%m%d_%H%M%S")

print(f"Training run: {RUN_ID}")

# COMMAND ----------

# Cell 2: Create metrics tracking table
spark.sql("""
    CREATE TABLE IF NOT EXISTS healthcare_platform.model_metrics (
        run_id          STRING,
        model_name      STRING,
        accuracy        DOUBLE,
        f1_score        DOUBLE,
        training_rows   LONG,
        feature_cols    STRING,
        trained_at      TIMESTAMP
    )
    USING DELTA
""")

spark.sql("""
    ALTER TABLE healthcare_platform.model_metrics
    SET TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported')
""")

spark.sql("""
    ALTER TABLE healthcare_platform.model_metrics
    ALTER COLUMN trained_at SET DEFAULT current_timestamp()
""")

print("✅ model_metrics table ready")

# COMMAND ----------

# Cell 3: Load gold layer data for training
def load_training_data():
    """
    Joins gold_patient_summary with gold_risk_scores
    to build a feature matrix for training.
    """
    df = spark.sql("""
        SELECT
            ps.patient_id,
            ps.age_years,
            CASE ps.gender
                WHEN 'M' THEN 0.0
                WHEN 'F' THEN 1.0
                ELSE 2.0
            END                             AS gender_encoded,
            COALESCE(ps.avg_systolic_bp,  120.0) AS avg_systolic_bp,
            COALESCE(ps.avg_diastolic_bp,  80.0) AS avg_diastolic_bp,
            COALESCE(ps.avg_heart_rate,    72.0) AS avg_heart_rate,
            COALESCE(ps.avg_spo2_pct,      98.0) AS avg_spo2_pct,
            COALESCE(ps.active_medications, 0)   AS active_medications,
            COALESCE(ps.total_readings,     0)   AS total_readings,
            rs.risk_level                        AS label
        FROM gold.gold_patient_summary  ps
        JOIN gold.gold_risk_scores      rs
          ON ps.patient_id = rs.patient_id
        WHERE rs.risk_level IS NOT NULL
    """)

    total = df.count()
    print(f"✅ Training data loaded: {total:,} rows")
    print(f"\nRisk level distribution:")
    df.groupBy("label").count().orderBy("label").show()

    return df

training_df = load_training_data()

# COMMAND ----------

# Cell 4: Build ML Pipeline
FEATURE_COLS = [
    "age_years",
    "gender_encoded",
    "avg_systolic_bp",
    "avg_diastolic_bp",
    "avg_heart_rate",
    "avg_spo2_pct",
    "active_medications",
    "total_readings"
]

def build_pipeline() -> Pipeline:
    """
    Builds a Spark ML Pipeline:
    1. StringIndexer  — encodes risk_level to numeric label
    2. VectorAssembler — combines features into one vector
    3. StandardScaler  — normalises features
    4. RandomForest    — classifier
    5. IndexToString   — converts prediction back to label name
    """
    label_indexer = StringIndexer(
        inputCol="label",
        outputCol="label_idx",
        handleInvalid="keep"
    )

    assembler = VectorAssembler(
        inputCols=FEATURE_COLS,
        outputCol="raw_features",
        handleInvalid="keep"
    )

    scaler = StandardScaler(
        inputCol="raw_features",
        outputCol="features",
        withMean=True,
        withStd=True
    )

    rf = RandomForestClassifier(
        labelCol="label_idx",
        featuresCol="features",
        numTrees=100,
        maxDepth=6,
        seed=42
    )

    label_converter = IndexToString(
        inputCol="prediction",
        outputCol="predicted_risk",
        labels=[]          # filled at fit time from label_indexer
    )

    pipeline = Pipeline(stages=[
        label_indexer,
        assembler,
        scaler,
        rf,
        label_converter
    ])

    return pipeline

pipeline = build_pipeline()
print("✅ Pipeline built successfully")
print(f"   Features: {FEATURE_COLS}")

# COMMAND ----------

# Cell 5: Train, evaluate, save model
def train_and_evaluate(df, pipeline):
    """
    Splits data, trains pipeline, evaluates accuracy and F1,
    saves model to Workspace path.
    """
    # Split — 80% train, 20% test
    train_df, test_df = df.randomSplit([0.8, 0.2], seed=42)

    print(f"Training rows : {train_df.count():,}")
    print(f"Test rows     : {test_df.count():,}")

    # Train
    print("\nTraining model...")
    model = pipeline.fit(train_df)

    label_model = model.stages[0]
    model.stages[-1].setLabels(label_model.labels)

    # Evaluate on test set
    predictions = model.transform(test_df)

    evaluator_acc = MulticlassClassificationEvaluator(
        labelCol="label_idx",
        predictionCol="prediction",
        metricName="accuracy"
    )
    evaluator_f1 = MulticlassClassificationEvaluator(
        labelCol="label_idx",
        predictionCol="prediction",
        metricName="f1"
    )

    accuracy = evaluator_acc.evaluate(predictions)
    f1       = evaluator_f1.evaluate(predictions)

    print(f"\n📊 Model Evaluation:")
    print(f"   Accuracy : {accuracy:.4f}")
    print(f"   F1 Score : {f1:.4f}")

    # Show confusion matrix
    print("\nConfusion Matrix (predicted vs actual):")
    predictions.groupBy("label", "predicted_risk") \
               .count() \
               .orderBy("label", "predicted_risk") \
               .show()

    # Save model
    model.write().overwrite().save(MODEL_PATH)
    print(f"\n✅ Model saved to: {MODEL_PATH}")

    # Save metrics to Delta
    metrics_data = [(
        RUN_ID,
        "RandomForestRiskClassifier",
        float(accuracy),
        float(f1),
        int(train_df.count()),
        json.dumps(FEATURE_COLS),
        datetime.now(timezone.utc).isoformat()
    )]

    metrics_df = spark.createDataFrame(
        metrics_data,
        ["run_id", "model_name", "accuracy", "f1_score",
         "training_rows", "feature_cols", "trained_at"]
    )
    # Save metrics to a NEW table name to avoid existing schema conflict
    metrics_df.write.format("delta") \
              .mode("overwrite") \
              .saveAsTable("workspace.healthcare_platform.model_metrics_v2")

    print(f"📋 Metrics saved to model_metrics_v2 table successfully")

    #print(f"📋 Metrics saved to model_metrics table")
    return model, accuracy, f1

    print(f"📋 Metrics saved to model_metrics table")
    return model, accuracy, f1

model, accuracy, f1 = train_and_evaluate(training_df, pipeline)