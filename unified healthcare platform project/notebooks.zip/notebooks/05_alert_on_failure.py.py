# Databricks notebook source
# notebooks/pipeline/05_alert_on_failure.py
# Runs only when a workflow task fails
# Called via on-failure dependency in the workflow

import json
import urllib.request
from datetime import datetime, timezone
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Get job metadata from environment variables (works on Serverless)
import os
job_id     = os.environ.get("DB_JOB_ID", "INTERACTIVE")
job_run_id = os.environ.get("DB_JOB_RUN_ID", "INTERACTIVE")
workspace  = os.environ.get("DATABRICKS_HOST", "https://dbc-03441693-0c6d.cloud.databricks.com")
if not workspace.startswith("http"):
    workspace = f"https://{workspace}"
timestamp  = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

print(f"Alert notebook triggered for run: {job_run_id}")

try:
    slack_url = dbutils.secrets.get(
        "healthcare-scope", "slack-webhook-url"
    )
    run_url = f"{workspace}/#job/{job_id}/run/{job_run_id}"

    payload = {
        "attachments": [{
            "color": "#E24B4A",
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": "🚨 Healthcare Pipeline FAILED"
                    }
                },
                {
                    "type": "section",
                    "fields": [
                        {"type": "mrkdwn",
                         "text": f"*Run ID:*\n{job_run_id}"},
                        {"type": "mrkdwn",
                         "text": f"*Time:*\n{timestamp}"},
                    ]
                },
                {
                    "type": "actions",
                    "elements": [{
                        "type": "button",
                        "text": {"type": "plain_text",
                                 "text": "View Run"},
                        "url": run_url,
                        "style": "danger"
                    }]
                }
            ]
        }]
    }

    body = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(
        slack_url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        print(f"✅ Slack alert sent: HTTP {resp.status}")

except Exception as e:
    print(f"Alert failed: {e}")

dbutils.notebook.exit("ALERTED")