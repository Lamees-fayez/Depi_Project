# Databricks notebook source
# Cell 1: Imports and setup
import json
import re
from datetime import datetime
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, BooleanType,
    TimestampType, IntegerType, DoubleType
)

spark = SparkSession.builder.getOrCreate()

# Constants
METADATA_TABLE   = "healthcare_platform.metadata_config"
REJECTED_TABLE   = "healthcare_platform.rejected_records"
BRONZE_DB        = "bronze"
AUDIT_COL_PREFIX = "_ingestion"

print("✅ Imports loaded successfully")

# COMMAND ----------

# Cell 2: Create rejected_records table if it does not exist
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS healthcare_platform.rejected_records (
        rejection_id        STRING,
        source_name         STRING,
        file_name           STRING,
        row_number          LONG,
        national_id_value   STRING,
        rejection_reason    STRING,
        raw_data            STRING,
        rejected_at         TIMESTAMP
    )
    USING DELTA
    TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")

print("✅ rejected_records table ready")

# COMMAND ----------

# Cell 3: Load a single source config from metadata_config
def load_source_config(source_name: str) -> dict:
    """
    Reads one row from metadata_config and returns it as a dict.
    Fails immediately if source is not found or not active.
    """
    rows = spark.sql(f"""
        SELECT * FROM {METADATA_TABLE}
        WHERE source_name = '{source_name}'
          AND is_active = true
    """).collect()

    if not rows:
        raise ValueError(
            f"Source '{source_name}' not found in metadata_config "
            f"or is_active = false"
        )

    config = rows[0].asDict()

    # Parse JSON string columns into Python objects
    for json_col in ["expected_columns", "optional_columns",
                     "coalesce_fields", "column_mapping"]:
        raw = config.get(json_col)
        if raw:
            try:
                config[json_col] = json.loads(raw)
            except json.JSONDecodeError:
                config[json_col] = []
        else:
            config[json_col] = [] if json_col != "column_mapping" else {}

    print(f"✅ Config loaded for source: {source_name}")
    print(f"   Format        : {config['file_format']}")
    print(f"   Target table  : {config['source_table']}")
    print(f"   Load strategy : {config['load_strategy']}")
    print(f"   National ID   : {config['national_id_filter']}")

    return config

# COMMAND ----------

# Cell 4: CSV reader with schema variation handling — FIXED
def read_csv_with_schema_handling(
    file_path: str,
    config: dict
) -> DataFrame:

    delimiter       = config.get("csv_delimiter", ",")
    has_header      = config.get("csv_header", True)
    encoding        = config.get("csv_encoding", "UTF-8")
    expected_cols   = config.get("expected_columns", [])
    optional_cols   = config.get("optional_columns", [])
    column_mapping  = config.get("column_mapping", {})

    print(f"\n📂 Reading CSV: {file_path}")

    raw_df = (
        spark.read.format("csv")
        .option("header",      has_header)
        .option("delimiter",   delimiter)
        .option("encoding",    encoding)
        .option("inferSchema", False)
        .option("mode",        "PERMISSIVE")
        .load(file_path)
    )

    print(f"   Raw columns   : {raw_df.columns}")
    print(f"   Raw row count : {raw_df.count():,}")

    # ── Step 1: Apply column mapping ───────────────────────────────────────────
    for incoming_name, standard_name in column_mapping.items():
        if incoming_name in raw_df.columns:
            raw_df = raw_df.withColumnRenamed(incoming_name, standard_name)
            print(f"   Renamed column: '{incoming_name}' → '{standard_name}'")

    # ── Step 2: Add missing optional columns as NULL (only if NOT present) ─────
    for col in optional_cols:
        if col not in raw_df.columns:          # ← KEY FIX: check first
            raw_df = raw_df.withColumn(col, F.lit(None).cast(StringType()))
            print(f"   Added missing optional column as NULL: '{col}'")
        else:
            print(f"   Optional column already present: '{col}' — skipping")

    # ── Step 3: Check required columns are present ─────────────────────────────
    required_cols   = [c for c in expected_cols if c not in optional_cols]
    missing_required = [c for c in required_cols if c not in raw_df.columns]

    if missing_required:
        raise ValueError(
            f"FATAL: Required columns missing from CSV: {missing_required}\n"
            f"CSV has: {raw_df.columns}\n"
            f"Expected: {expected_cols}"
        )

    # ── Step 4: Drop unexpected columns ───────────────────────────────────────
    all_allowed_cols = expected_cols + [c for c in optional_cols
                                        if c not in expected_cols]
    extra_cols = [c for c in raw_df.columns if c not in all_allowed_cols]
    if extra_cols:
        print(f"   Dropping unexpected columns: {extra_cols}")
        raw_df = raw_df.drop(*extra_cols)

    # ── Step 5: Select in defined order, no duplicates ─────────────────────────
    seen      = set()
    final_cols = []
    for c in all_allowed_cols:
        if c in raw_df.columns and c not in seen:
            final_cols.append(c)
            seen.add(c)

    aligned_df = raw_df.select(*final_cols)
    print(f"   Aligned columns: {aligned_df.columns}")
    return aligned_df

# COMMAND ----------

# Cell 5: National ID filter
def apply_national_id_filter(
    df: DataFrame,
    config: dict,
    file_name: str,
    source_name: str
) -> tuple[DataFrame, DataFrame]:
    """
    Splits the DataFrame into:
      - valid_df   : rows where national_id is exactly 14 numeric digits
      - rejected_df: rows that fail the check, written to rejected_records

    Returns (valid_df, rejected_df)
    """
    if not config.get("national_id_filter", False):
        print("   National ID filter: DISABLED — skipping")
        return df, spark.createDataFrame([], df.schema)

    id_col    = config.get("national_id_col", "national_id")
    id_length = config.get("national_id_length", 14)

    print(f"\n🔍 Applying National ID filter on column: '{id_col}'")
    print(f"   Required: exactly {id_length} numeric digits")

    if id_col not in df.columns:
        raise ValueError(
            f"National ID column '{id_col}' not found in DataFrame. "
            f"Available columns: {df.columns}"
        )

    # Add row index for traceability
    df = df.withColumn("_row_number", F.monotonically_increasing_id())

    # Validation condition: exactly id_length digits, no letters/spaces
    valid_pattern   = f"^[0-9]{{{id_length}}}$"
    is_valid        = F.col(id_col).rlike(valid_pattern)

    valid_df    = df.filter(is_valid).drop("_row_number")
    invalid_df  = df.filter(~is_valid)

    # Build rejected_records rows
    rejected_df = invalid_df.select(
        F.expr("uuid()")                        .alias("rejection_id"),
        F.lit(source_name)                      .alias("source_name"),
        F.lit(file_name)                        .alias("file_name"),
        F.col("_row_number")                    .alias("row_number"),
        F.col(id_col)                           .alias("national_id_value"),
        F.when(F.col(id_col).isNull(),
               "National ID is NULL")
         .when(~F.col(id_col).rlike("^[0-9]+$"),
               "National ID contains non-numeric characters")
         .when(F.length(F.col(id_col)) != id_length,
               F.concat(
                   F.lit("National ID length is "),
                   F.length(F.col(id_col)).cast(StringType()),
                   F.lit(f" digits — expected {id_length}")
               ))
         .otherwise("Failed National ID validation")  .alias("rejection_reason"),
        F.to_json(F.struct(*[c for c in df.columns
                             if c != "_row_number"]))  .alias("raw_data"),
        F.current_timestamp()                          .alias("rejected_at")
    )

    valid_count    = valid_df.count()
    rejected_count = rejected_df.count()

    print(f"   ✅ Valid rows    : {valid_count:,}")
    print(f"   ❌ Rejected rows : {rejected_count:,}")

    return valid_df, rejected_df

# COMMAND ----------

# Cell 6: Bronze writer — FIXED
# Writes to a dedicated ingestion table separate from dbt-managed bronze tables
def write_to_bronze(
    df: DataFrame,
    config: dict,
    file_name: str
) -> int:

    from datetime import timezone

    source_name   = config["source_name"]
    primary_key   = config["primary_key"]
    load_strategy = config.get("load_strategy", "incremental")

    # Dedicated ingestion table — does NOT overwrite dbt bronze tables
    bronze_table  = f"healthcare_platform.bronze_ingestion_{source_name}"

    print(f"\n💾 Writing to bronze table: {bronze_table}")
    print(f"   Primary key : {primary_key}")
    print(f"   Strategy    : {load_strategy}")

    # Add audit columns
    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

    df = (
        df
        .withColumn("_source_file",      F.lit(file_name))
        .withColumn("_source_name",      F.lit(source_name))
        .withColumn("_ingested_at",      F.current_timestamp())
        .withColumn("_ingestion_run_id", F.lit(run_id))
    )

    row_count = df.count()

    if load_strategy == "full_refresh":
        (
            df.write
            .format("delta")
            .mode("overwrite")
            .option("overwriteSchema", "true")
            .saveAsTable(bronze_table)
        )
        print(f"   Full refresh — overwrote {row_count:,} rows")

    else:
        # ── Check if table exists using SQL only (Spark Connect safe) ──────────
        try:
            spark.sql(f"SELECT 1 FROM {bronze_table} LIMIT 1")
            table_exists = True
        except Exception:
            table_exists = False

        if not table_exists:
            (
                df.write
                .format("delta")
                .mode("overwrite")
                .saveAsTable(bronze_table)
            )
            print(f"   Table created — inserted {row_count:,} rows")

        else:
            # Verify primary key exists in both source and target
            target_cols = spark.sql(
                f"SELECT * FROM {bronze_table} LIMIT 1"
            ).columns

            if primary_key not in target_cols:
                raise ValueError(
                    f"Primary key '{primary_key}' not found in target table "
                    f"'{bronze_table}'.\nTarget columns: {target_cols}\n"
                    f"Source columns: {df.columns}"
                )

            if primary_key not in df.columns:
                raise ValueError(
                    f"Primary key '{primary_key}' not found in source DataFrame."
                    f"\nSource columns: {df.columns}"
                )

            df.createOrReplaceTempView("_incoming")

            spark.sql(f"""
                MERGE INTO {bronze_table} AS target
                USING _incoming             AS source
                ON target.{primary_key} = source.{primary_key}
                WHEN MATCHED THEN
                    UPDATE SET *
                WHEN NOT MATCHED THEN
                    INSERT *
            """)
            print(f"   Incremental merge — processed {row_count:,} rows")

    return row_count

# COMMAND ----------

# Cell 7: Metadata updater — FIXED
def update_metadata(
    source_name: str,
    file_name: str,
    rows_loaded: int,
    rows_rejected: int
) -> None:

    # Escape single quotes in filename
    safe_file_name = file_name.replace("'", "''")

    spark.sql(f"""
        UPDATE {METADATA_TABLE}
        SET
            last_ingested_at    = current_timestamp(),
            last_file_loaded    = '{safe_file_name}',
            total_rows_loaded   = total_rows_loaded   + {rows_loaded},
            total_rows_rejected = total_rows_rejected + {rows_rejected},
            last_updated        = current_timestamp()
        WHERE source_name = '{source_name}'
    """)
    print(f"\n📊 Metadata updated for '{source_name}'")
    print(f"   Rows loaded   : {rows_loaded:,}")
    print(f"   Rows rejected : {rows_rejected:,}")

# COMMAND ----------

# Cell 8: Master ingestion function — FIXED datetime warnings
def run_ingestion(source_name: str, file_path: str) -> dict:

    from datetime import timezone
    print(f"\n{'='*60}")
    print(f"  INGESTION START: {source_name}")
    print(f"  File: {file_path}")
    print(f"{'='*60}")

    start_time = datetime.now(timezone.utc)
    file_name  = file_path.split("/")[-1]

    try:
        config      = load_source_config(source_name)
        aligned_df  = read_csv_with_schema_handling(file_path, config)

        valid_df, rejected_df = apply_national_id_filter(
            aligned_df, config, file_name, source_name
        )

        rows_loaded   = write_to_bronze(valid_df, config, file_name)
        rows_rejected = rejected_df.count()

        if rows_rejected > 0:
            (
                rejected_df.write
                .format("delta")
                .mode("append")
                .saveAsTable("healthcare_platform.rejected_records")
            )
            print(f"\n⚠️  {rows_rejected:,} rejected rows written to rejected_records")

        update_metadata(source_name, file_name, rows_loaded, rows_rejected)

        duration = (datetime.now(timezone.utc) - start_time).seconds
        summary  = {
            "status":        "SUCCESS",
            "source_name":   source_name,
            "file":          file_name,
            "rows_loaded":   rows_loaded,
            "rows_rejected": rows_rejected,
            "duration_sec":  duration
        }

    except Exception as e:
        duration = (datetime.now(timezone.utc) - start_time).seconds
        print(f"\n❌ INGESTION FAILED: {e}")
        summary = {
            "status":       "FAILED",
            "source_name":  source_name,
            "file":         file_name,
            "error":        str(e),
            "duration_sec": duration
        }

    print(f"\n{'='*60}")
    print(f"  INGESTION COMPLETE — Status: {summary['status']}")
    print(f"{'='*60}\n")

    return summary

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE healthcare_platform.metadata_config
# MAGIC SET file_source_path = '/Workspace/Shared/healthcare/uploads/'
# MAGIC WHERE source_name = 'patients_csv';

# COMMAND ----------

# Cell 9: Write sample CSV directly to Workspace filesystem
import pandas as pd
import os

sample_data = {
    "national_id":   ["12345678901234", "98765432109876",
                      "1234",           "ABCD12345678",   "56789012345678"],
    "first_name":    ["Ahmed",  "Sara",   "Omar",  "Nadia",  "Layla"],
    "last_name":     ["Hassan", "Khalid", "Farouk","Nour",   "Hassan"],
    "date_of_birth": ["1985-03-12","1990-11-05","1972-07-28",
                      "1995-06-30","1965-01-19"],
    "gender":        ["M", "F", "M", "F", "F"],
    "blood_type":    ["A+","O-","B+","AB+","O+"],
    "contact_email": ["ahmed@example.com","sara@example.com",
                      "omar@example.com","nadia@example.com",
                      "layla@example.com"]
}

pdf = pd.DataFrame(sample_data)

# ── Create directory in Workspace filesystem ───────────────────────────────────
workspace_dir  = "/Workspace/Shared/healthcare/uploads"
workspace_file = f"{workspace_dir}/sample_patients.csv"

os.makedirs(workspace_dir, exist_ok=True)

# Write CSV using pandas directly (no Spark, no DBFS, no /tmp)
pdf.to_csv(workspace_file, index=False)

print(f"✅ Sample CSV written to: {workspace_file}")
print(f"\nPreview:")
print(pdf.to_string())

# ── Verify Spark can read it back ──────────────────────────────────────────────
verify_df = spark.read \
    .option("header", "true") \
    .csv(workspace_file)

print(f"\nSpark read back {verify_df.count()} rows successfully")
display(verify_df)

# COMMAND ----------

# Cell 10: Run ingestion and verify results
summary = run_ingestion(
    source_name = "patients_csv",
    file_path   = "/Workspace/Shared/healthcare/uploads/sample_patients.csv"
)

print("\n── Ingestion Summary ──")
for k, v in summary.items():
    print(f"  {k:20s}: {v}")

# Verify rejected records
print("\n── Rejected Records ──")
spark.sql("""
    SELECT
        national_id_value,
        rejection_reason,
        file_name,
        rejected_at
    FROM healthcare_platform.rejected_records
    ORDER BY rejected_at DESC
    LIMIT 10
""").show(truncate=False)

# Verify metadata updated
print("\n── Updated Metadata ──")
spark.sql("""
    SELECT
        source_name,
        total_rows_loaded,
        total_rows_rejected,
        last_file_loaded,
        last_ingested_at
    FROM healthcare_platform.metadata_config
    WHERE source_name = 'patients_csv'
""").show(truncate=False)