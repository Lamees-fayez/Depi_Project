# Databricks notebook source
# Create ML tables so app does not crash
spark.sql("""
    CREATE TABLE IF NOT EXISTS healthcare_platform.patient_risk_predictions (
        patient_id          STRING,
        predicted_risk      STRING,
        confidence_high     DOUBLE,
        confidence_medium   DOUBLE,
        confidence_low      DOUBLE,
        model_run_id        STRING,
        scored_at           TIMESTAMP
    )
    USING DELTA
""")

spark.sql("""
    CREATE TABLE IF NOT EXISTS healthcare_platform.anomaly_flags (
        anomaly_id      STRING,
        patient_id      STRING,
        vital_id        STRING,
        recorded_at     TIMESTAMP,
        anomaly_type    STRING,
        metric_name     STRING,
        metric_value    DOUBLE,
        expected_range  STRING,
        severity        STRING,
        detected_at     TIMESTAMP
    )
    USING DELTA
""")

spark.sql("""
    CREATE TABLE IF NOT EXISTS healthcare_platform.model_metrics (
        run_id          STRING,
        model_name      STRING,
        accuracy        DOUBLE,
        f1_score        DOUBLE,
        training_rows   LONG,
        feature_cols    STRING,
        trained_at      TIMESTAMP
    )
    USING DELTA
""")

print("✅ All ML tables created")