# Databricks notebook source
from pyspark.ml import PipelineModel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from datetime import datetime, timezone

spark = SparkSession.builder.getOrCreate()

# 1. تحديث المسار ليطابق الـ Volume الصحيح الذي وجدناه سابقاً
MODEL_PATH = "/Volumes/workspace/healthcare_platform/my_model_storage/risk_model"
PREDICTIONS_TABLE = "workspace.healthcare_platform.patient_risk_predictions"

# 2. إنشاء الجدول بشكل أكثر أماناً
# ملاحظة: أضفنا اسم الكتالوج/السكيمة الكامل للتأكد من المكان
spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {PREDICTIONS_TABLE} (
        patient_id STRING,
        predicted_risk STRING,
        confidence_high DOUBLE,
        confidence_medium DOUBLE,
        confidence_low DOUBLE,
        model_run_id STRING,
        scored_at TIMESTAMP
    )
    USING DELTA
""")

print(f"✅ Predictions table ready at: {PREDICTIONS_TABLE}")

# COMMAND ----------

def score_all_patients():
    # 1. الاستيرادات الضرورية داخل الدالة لضمان توفرها
    from datetime import datetime, timezone
    from pyspark.ml.pipeline import PipelineModel
    from pyspark.sql import functions as F
    
    # 2. تعريف الـ UDF داخل الدالة لضمان أنها معرفة دائماً قبل الاستخدام
    def extract_prob_func(v, i):
        return float(v[i])
    
    extract_prob = F.udf(extract_prob_func, "double")

    # 3. إعداد الـ run_id
    run_id = datetime.now(timezone.utc).strftime("SCR_%Y%m%d_%H%M%S")

    # 4. تحميل النموذج (مع التأكد من استخدام MODEL_PATH المعرف مسبقاً)
    model = PipelineModel.load(MODEL_PATH)
    print(f"✅ Model successfully loaded from: {MODEL_PATH}")

    # 5. تحميل البيانات
    patients_df = spark.sql("""
        SELECT
            ps.patient_id,
            COALESCE(ps.age_years,           30.0) AS age_years,
            CASE ps.gender
                WHEN 'M' THEN 0.0
                WHEN 'F' THEN 1.0
                ELSE 2.0
            END                                    AS gender_encoded,
            COALESCE(ps.avg_systolic_bp,    120.0) AS avg_systolic_bp,
            COALESCE(ps.avg_diastolic_bp,    80.0) AS avg_diastolic_bp,
            COALESCE(ps.avg_heart_rate,      72.0) AS avg_heart_rate,
            COALESCE(ps.avg_spo2_pct,        98.0) AS avg_spo2_pct,
            COALESCE(ps.active_medications,   0)   AS active_medications,
            COALESCE(ps.total_readings,       0)   AS total_readings
        FROM gold.gold_patient_summary ps
    """)

    # 6. إجراء التنبؤ
    predictions = model.transform(patients_df)

    # 7. استخراج الفهارس (Labels) من النموذج
    label_indexer = model.stages[0]
    labels = label_indexer.labelsArray[0]
    high_idx   = labels.index("HIGH")   if "HIGH"   in labels else 0
    medium_idx = labels.index("MEDIUM") if "MEDIUM" in labels else 1
    low_idx    = labels.index("LOW")    if "LOW"    in labels else 2

    # 8. تجهيز النتائج
    results = predictions.select(
        F.col("patient_id"),
        F.col("predicted_risk"),
        extract_prob(F.col("probability"), F.lit(high_idx)).alias("confidence_high"),
        extract_prob(F.col("probability"), F.lit(medium_idx)).alias("confidence_medium"),
        extract_prob(F.col("probability"), F.lit(low_idx)).alias("confidence_low"),
        F.lit(run_id).alias("model_run_id"),
        F.current_timestamp().alias("scored_at")
    )
    
    # 9. حفظ النتائج في الجدول
    results.write \
        .format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .saveAsTable(PREDICTIONS_TABLE)

    # 10. إخراج النتائج
    count = results.count()
    print(f"\n✅ Scored {count:,} patients and saved to {PREDICTIONS_TABLE}")
    results.groupBy("predicted_risk").count().show()

    return results

# استدعاء الدالة
predictions = score_all_patients()