# Databricks notebook source
# MAGIC %sql
# MAGIC -- Table 1: diagnostic_records — core metadata for every diagnostic
# MAGIC CREATE TABLE IF NOT EXISTS healthcare_platform.diagnostic_records (
# MAGIC     diagnostic_id     STRING NOT NULL,
# MAGIC     patient_id        STRING NOT NULL,
# MAGIC     diagnostic_type   STRING NOT NULL,  -- LAB, XRAY, CT, MRI, ULTRASOUND, ECG, OTHER
# MAGIC     diagnostic_name   STRING NOT NULL,  -- e.g. "Complete Blood Count", "Chest X-Ray"
# MAGIC     diagnostic_date   DATE,
# MAGIC     result_summary    STRING,           -- text summary of findings
# MAGIC     result_status     STRING,           -- NORMAL, ABNORMAL, CRITICAL, PENDING
# MAGIC     ordering_doctor   STRING,
# MAGIC     performing_lab    STRING,
# MAGIC     notes             STRING,
# MAGIC     file_name         STRING,           -- original uploaded file name
# MAGIC     file_path         STRING,           -- path in workspace
# MAGIC     file_type         STRING,           -- PDF, JPG, PNG, DICOM
# MAGIC     file_size_kb      DOUBLE,
# MAGIC     created_at        TIMESTAMP,
# MAGIC     created_by        STRING,           -- patient or doctor
# MAGIC     last_updated      TIMESTAMP
# MAGIC )
# MAGIC USING DELTA
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
# MAGIC
# MAGIC -- Enable column defaults
# MAGIC ALTER TABLE healthcare_platform.diagnostic_records
# MAGIC SET TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported');
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.diagnostic_records
# MAGIC     ALTER COLUMN created_at  SET DEFAULT current_timestamp();
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.diagnostic_records
# MAGIC     ALTER COLUMN last_updated SET DEFAULT current_timestamp();
# MAGIC
# MAGIC -- Table 2: lab_results — structured lab values
# MAGIC CREATE TABLE IF NOT EXISTS healthcare_platform.lab_results (
# MAGIC     lab_result_id     STRING NOT NULL,
# MAGIC     diagnostic_id     STRING NOT NULL,
# MAGIC     patient_id        STRING NOT NULL,
# MAGIC     test_name         STRING NOT NULL,
# MAGIC     test_value        DOUBLE,
# MAGIC     test_unit         STRING,
# MAGIC     reference_min     DOUBLE,
# MAGIC     reference_max     DOUBLE,
# MAGIC     is_abnormal       BOOLEAN,
# MAGIC     recorded_at       TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.lab_results
# MAGIC SET TBLPROPERTIES ('delta.feature.allowColumnDefaults' = 'supported');
# MAGIC
# MAGIC ALTER TABLE healthcare_platform.lab_results
# MAGIC     ALTER COLUMN recorded_at SET DEFAULT current_timestamp();

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE workspace.healthcare_platform.medications 
# MAGIC ADD COLUMNS (
# MAGIC     file_name STRING,
# MAGIC     file_path STRING,
# MAGIC     file_type STRING
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW healthcare_platform.vw_patient_diagnostics AS
# MAGIC SELECT
# MAGIC     d.diagnostic_id,
# MAGIC     d.patient_id,
# MAGIC     p.first_name || ' ' || p.last_name  AS full_name,
# MAGIC     d.diagnostic_type,
# MAGIC     d.diagnostic_name,
# MAGIC     d.diagnostic_date,
# MAGIC     d.result_summary,
# MAGIC     d.result_status,
# MAGIC     d.ordering_doctor,
# MAGIC     d.performing_lab,
# MAGIC     d.notes,
# MAGIC     d.file_name,
# MAGIC     d.file_type,
# MAGIC     d.file_size_kb,
# MAGIC     d.created_at,
# MAGIC     d.created_by
# MAGIC FROM healthcare_platform.diagnostic_records d
# MAGIC JOIN healthcare_platform.patients p
# MAGIC   ON d.patient_id = p.patient_id
# MAGIC ORDER BY d.diagnostic_date DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Run in Databricks notebook or SQL Warehouse
# MAGIC ALTER TABLE workspace.healthcare_platform.diagnostic_records
# MAGIC ADD COLUMN file_content STRING;
# MAGIC
# MAGIC -- This stores the base64 encoded file content
# MAGIC -- Works for PDFs up to ~5MB and images